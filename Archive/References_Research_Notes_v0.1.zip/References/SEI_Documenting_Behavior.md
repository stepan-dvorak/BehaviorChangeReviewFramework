# SEI – Documenting Behavior

---
status: stub
version: 0.1
---

# Purpose

Working reference note for the Behavior Change Review Framework project.

# Summary

SEI recognizes behavior as an architectural view and discusses documenting runtime behavior.

# Relevance to the Research

Strong evidence that behavior is architectural.

# Concepts to Extract

- Terminology
- Definitions
- Review methodology
- Behavioral aspects
- Architectural implications

# Potential Contribution to the Project

- Reusable terminology
- Supporting evidence
- Possible counterarguments
- Gaps in current guidance

# Open Research Questions

Open: Is there guidance for reviewing behavior modifications?

# Action Items

- Read primary source.
- Capture exact terminology.
- Record quotations only where appropriate.
- Compare with [[01_Terminology]] and [[03_Related_Work]].

# References

To be completed after detailed literature review.
